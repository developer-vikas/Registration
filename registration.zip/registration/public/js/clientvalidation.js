
function validate(){
    var regName = /^[a-zA-Z]+ [a-zA-Z]+$/;
    var name = document.getElementById('name').value;
    if(!regName.test(name)){
        alert('Please enter valid name.');
        document.getElementById('name').focus();
        return false;
    }else{
        return true;
    }

    
}

function validate(){
    var regEmail = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
    var email = document.getElementById('email').value;
    if(!regEmail.test(email)){
        alert("Please enter valid email.");
        document.getElementById('email').focus()
        return false;
    }
    else{
        return true;
    }
}

function validate(){
    var regMobile = /^\(?(\d{3})\)?[- ]?(\d{3})[- ]?(\d{4})$/;
    var mobile = document.getElementById('mobile').value;
    if(!regMobile.test(mobile)){
        alert("Please enter valid Phone Number.");
        document.getElementById('mobile').focus()
        return false;
    }
    else{
        return true;
    }
}
