const { urlencoded, response } = require('express');
const express = require('express');
const bodyParser = require('body-parser');
const Router = express.Router();
const homeSchema = require('../models/homeSchema');
const bcrypt = require('bcryptjs')
var {check,validationResult} = require('express-validator');


Router.get('/',(req,res)=>{
    res.render('index');
})

Router.get('/register',
(req,res)=>{
    res.render('register',{title:'',password:'',email:'',alert:''})
})



Router.post('/register', [
    //Custom Validation for Name
    check('name').custom((value,{req})=>{
        if(isNaN(value)){
            return true;
        }else{
            throw new Error('invalid name')
        }
    }),

    //Express-validator for Email
    check('email','Email is not valid') 
    .isEmail()
    .notEmpty()
    .normalizeEmail(),
        

    //Express-validator for Phone Number
    check('mobile','Enter valid Mobile Number')
    .isMobilePhone()
    .isLength({min:10,max:10}),

    ],async(req,res)=>{

    const errors = validationResult(req);
    
    if(!errors.isEmpty()) {
        const alert= res.status(422).jsonp(errors.array());
        return alert;
        
    }

    try{

        const name = req.body.name;
        const email = req.body.email;
        const mobile = req.body.mobile;   
        const pass = req.body.pass;
        const re_pass = req.body.re_pass;



        //Check Password and confirm password
        if(pass===re_pass){
            
            const user = new homeSchema({
              name:req.body.name,
              email: req.body.email,
              mobile: req.body.mobile,  
              pass: req.body.pass,
              re_pass: req.body.re_pass,

            })

            

            user.save(user)
            .then(data=>{

                res.redirect('/home');
              
            })
            .catch(err=>{
                res.status(400).send('Item Failed to save in Database');
            })



        }
        else{
            res.render('register',{title:'',password:'Password not match',email:'',alert:''});    
        }

        }catch(error){
            res.render('register',{title:'Error in code',password:'',email:'',alert:''})
        }
})



//Login Functionality
Router.get('/login',(req,res)=>{
    res.render('login',{password:'',errmsg:''});
})



//Login Functionality

Router.post('/login',async(req,res)=>{

    try {
    const email = req.body.email;
    const pass = req.body.pass;

    const user = new homeSchema({
        email:req.body.email,
        pass:req.body.pass,
    })

    const users = await homeSchema.findOne({email:email});


    if(pass===users.pass)
    {
        res.redirect('home');
    }
    else
    {
        res.render('login',{password:'Username and Password did not Matched', errmsg:''});
    }
        
    } catch (error) {
        res.render('login',{password:'',errmsg:'Invalid User Details'})
    }
   
})







//Home Page Redirect
Router.get('/home',(req,res)=>{
    res.render('home');
})

module.exports= Router;